﻿using System;

namespace Method_plus
{
    class Program
    {
        static void Main(string[] args)
        {

          Start Start = new Start();

        }

    



    }
}
