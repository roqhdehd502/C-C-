﻿using System;

namespace Method_plus
{



    public class Plus
    {


        public Plus()
        {
            Console.WriteLine("hello c#========================================================");

        }

        public Plus(int a)
        {
            Console.WriteLine("hello c#========================================================");

        }

        public Plus(String a)
        {
            Console.WriteLine("hello c#========================================================");

        }

        public Plus(long a)
        {
            Console.WriteLine("hello c#========================================================");

        }

     



        public int bbb()


        {
            int a = 10;
            return a;
        }



        public int logic (int a, int b)
        {

            Console.WriteLine("hello c#");
            return a + b;

           

        }



        public int add(int a, int b)
        {

            int c = a + b;
            
            return c;

        }




        public int add(int a, int b,int c, int d)
        {


       

            return a + b;

        }



        public void aa()
        {


         
            
          

                 int  a  = add(10, 2);
        }
            


     








    }
}
