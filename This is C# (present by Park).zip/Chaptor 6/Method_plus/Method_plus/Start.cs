﻿using System;

namespace Method_plus
{
   public  class Start
    {

        int a = 10;



        Start()
        {

        }



        public void aa()
        {
            Console.WriteLine("aastart");
            Plus plus = new Plus("a");

            aa();

        }



        public int abc(int a)
        {

            this.a = a;
        }




    }
}
