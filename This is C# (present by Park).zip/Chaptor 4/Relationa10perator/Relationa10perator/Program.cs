﻿using System;

namespace Relationa10perator
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("3 > 4 : " + (3 > 4));
            Console.WriteLine("3 >= 4 : " + (3 >= 4));
            Console.WriteLine("3 < 4 : " + (3 < 4));
            Console.WriteLine("3 <= 4 : " + (3 <= 4));
            Console.WriteLine("3 == 4 : " + (3 == 4));
            Console.WriteLine("3 != 4 : " + (3 != 4));
        }
    }
}
