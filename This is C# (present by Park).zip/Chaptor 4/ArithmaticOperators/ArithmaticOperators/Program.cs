﻿using System;

namespace ArithmaticOperators
{
    class Program
    {
        static void Main(string[] args)
        {
            int e = 10;
            Console.WriteLine(e); // 초기값은 10. 
            Console.WriteLine(""); // 후위 연산자로 스택을 쌓으면 어떻게 되는지 알아보자.

            Console.WriteLine(e++); // 처음에는 그대로 10일테지만
            Console.WriteLine(e++); // 쌓을 수록 1씩 증가하는 걸 알 수 있습니다.
        }
    }
}
