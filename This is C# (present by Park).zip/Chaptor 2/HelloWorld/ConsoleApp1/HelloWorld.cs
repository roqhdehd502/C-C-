﻿using System;

namespace ConsoleApp1
{
    class HelloWorld
    {
        static void Main(string[] args)
        {
            int a = add(1, 2); // 그래서
            Console.WriteLine(a); //

            if (args.Length == 0)
            {
                Console.WriteLine("사용법 : HelloWorld.exe <이름>");
            }

           // Console.WriteLine("Hello, {0}!", args[0]);
        }
        public static int add(int a, int b) // 넣었습니다.
        { //
            return a + b; // ㅋ
        } //
    }
}