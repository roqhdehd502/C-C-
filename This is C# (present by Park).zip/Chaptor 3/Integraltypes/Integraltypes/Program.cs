﻿using System;

namespace Integraltypes
{
    class Program
    {
        static void Main(string[] args)
        {
            sbyte a = -10;
            byte b = 40;

            Console.WriteLine($"a={a}, b={b}");

            short c = -30000;
            ushort d = 60000;

            Console.WriteLine($"c={c}, d={d}");

            int e = -1000_0000; // 0이 7개
            uint f = 3_000_0000; // 0이 8개

            Console.WriteLine($"e={e}. f={f}");

            long g = -5000_0000_0000; // 0이 11개
            ulong h = 200_0000_0000_0000_0000; // 0이 18개

            Console.WriteLine($"g={g}, h={h}");

            byte i= 240; // 10진수 리터럴
            Console.WriteLine($"i={i}");

            byte j = 0b1111_0000; // 2진수 리터럴
            Console.WriteLine($"j={j}");

            byte k = 0XF0; // 16진수 리터럴
            Console.WriteLine($"k={k}");

            uint l = 0x1234_abcd; // 16진수 리터럴
            Console.WriteLine($"l={l}");

            byte m = 255;
            sbyte n = (sbyte)m;

            Console.WriteLine(m);
            Console.WriteLine(n);

            float o = 3.1415_9265_3589_7932_3846f;
            Console.WriteLine(o);

            double p = 3.1415_9265_3589_7932_3846;
            Console.WriteLine(p);

            decimal q = 3.1415_9265_3589_7932_3846_2643_3832_79m;
            Console.WriteLine(q);

            char r = '안';
            Console.WriteLine(r);

            string s = "Hello World!";
            Console.WriteLine(s);

            object t = "I say 128";
            Console.WriteLine(t);
        }
    }
}
